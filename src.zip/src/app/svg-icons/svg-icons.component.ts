import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-svg-icons',
  templateUrl: './svg-icons.component.html',
  styleUrls: ['./svg-icons.component.css']
})
export class SvgIconsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
