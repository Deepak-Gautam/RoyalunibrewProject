
export class EntryLogs {
// id: number;
LicenseNumber: string;
TrailerNumber: string;
Name: string;
CompanyName: string;
Destination: string;
DateTime: string;
}
