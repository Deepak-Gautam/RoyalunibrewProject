// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: 'AIzaSyDg13M3gsgSq7SLXCDv9g-14bSv0DXyxK4',
    authDomain: 'fistfirebase-9ec46.firebaseapp.com',
    databaseURL: 'https://fistfirebase-9ec46.firebaseio.com',
    projectId: 'fistfirebase-9ec46',
    storageBucket: 'fistfirebase-9ec46.appspot.com',
    messagingSenderId: '603045966187',
    appId: '1:603045966187:web:685872a988494dce'
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
